## Critical drive example

<p align="center"><img src="/images/critical-1.png"></p>

<p align="center"><img src="/images/critical-3.png"></p>

<p align="center"><img src="/images/critical-4.png"></p>

<p align="center"><img src="/images/critical-5.png"></p>

<p align="center"><img src="/images/critical-6.png"></p>
